package temperatura;
import java.util.ArrayList;
public class Temperatura {

    public static void main(String[] args) throws Exception {
        
        ArrayList temperatura=new ArrayList();
        ArrayList umidita=new ArrayList();
        Cliente client=new Cliente();
        //lettura dati
        serialPortHandler p=new serialPortHandler();
        String valore=null;
        int indice=0;
        if(p.connect("COM4","Temperatura",9600)){
       // Random generatore = new Random();
       for(int i=0;i<101;i++)
       {
           temperatura.add(0);
           umidita.add(0);
       }
       while(true){
           System.out.print("");
        valore=p.readSerial();
        String s="";
        
        if(valore!=null)
            if(indice<100)
            {
               /*if(valore!=""){
               String t=valore.substring(0, valore.indexOf(";"));
               valore=valore.substring(valore.indexOf(";")+1);
               String u=valore.substring(0,valore.indexOf(";"));
               temperatura.add(indice, t);             
               umidita.add(indice,u);
               client.comunica(temperatura.get(indice).toString()+';'+umidita.get(indice).toString());
               indice++;
               }*/
                temperatura.add(indice, indice);             
               umidita.add(indice,indice);
                indice++;
            }else{
               client.connetti();
                for(int i=0;i<101;i++)
                {
                    s+=temperatura.get(i).toString();
                    s+="-"+umidita.get(i).toString()+";";
                }
                client.comunica(s);
                indice=0;
                
            }
        }
       
        }
       
        
    }
    
}
